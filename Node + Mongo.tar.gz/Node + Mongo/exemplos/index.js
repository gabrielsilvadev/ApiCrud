const mongoose = require('mongoose');
mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost/banco').then(()=>{
console.log('conectado...')
}).catch((err)=>{
  console.log(err)
})

const UserSchema = new mongoose.Schema({
    nome:{
        type: String,
        require:true
    },
    sobrenome:{
        type:String,
        require:true
    },
    email:{
        type:String,
        require:true
    },
    idade:{
        type:Number,
        require:true
    }
})
const  myModel = mongoose.model('User',UserSchema)

const m = new myModel;
m.save();