
const Project = require('../schema/modelProject')
const Task = require('../schema/modelTask')

module.exports={
async listProject(req,res){
   try{
     const projeto  = await Project.findById(req.params.projectId).populate('user','tasks') 
     return res.send({projeto})
    }catch(err){
       return res.status(400).send({err:"error"})
   }
},
async projectAll(req,res){
  const project =await Project.find().populate(['user','tasks'])
 return  res.send(project)
},
async create(req,res){
    const {title,description,tasks} = req.body
  try{
    const projetos = await Project.create({title,description,user:req.userId})
    await Promise.all(tasks.map(async task=>{
        const projectTask = new Task({...task,project:projetos._id})
          await projectTask.save()
          projetos.task.push(projectTask)
      
    }))
    await projetos.save();
    return res.send({projetos})
    }catch(error){
       return res.status(400).send({err:`${error}`})

    }
},
async edition(req,res){
 
},
async delete(req,res){
  try{
      await Project.findByIdAndRemove(req.params.projectId) 
     return res.send()
    }catch(err){
       return res.status(400).send({err:"error"})
   }
}
}