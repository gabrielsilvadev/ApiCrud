const MyModel = require('../schema/modelUser')

const bcrypt = require('bcryptjs')
const crypto = require('crypto')
const jwt = require('jsonwebtoken');


const auth = require('../config/autha.json');
const mailer = require('../modules/mailer');




module.exports ={
  async create(req,res,next){
   try{
    const {name,sobrenome,email,idade,password}= req.body
    
    await bcrypt.hash(password, 10).then(async(hash) => {
    const user =await  MyModel.create({
       name:name,
       sobrenome:sobrenome,
       email:email,
       idade:idade,
       password:hash

     })
      const token =  jwt.sign({id:user.id},auth.secret,{
        expiresIn:86400
      })
      await user.save()
        res.send({user,token})
        console.log(hash)
    });
    
   }catch(err){
    return res.status(400).send({err:`error the register ${err}`})
   }
 },

 async auth(req,res){
   const {email,password} = req.body
   
   const user = await MyModel.findOne({email}).select('+password');
    if(!user)
      return res.status(400).send({err:'User not exists'})
  
    if(!await bcrypt.compare(password,user.password))
      return res.status(400).send({erro:'Invalid password'})
    const token = jwt.sign({id:user.id},auth.secret,{
      expiresIn:86400
  }) 
  
  res.send({user,token})
  
  user.password=undefined
  },

   async validationUser(req,res){
     res.send({ok:true,user:req.userId})
    },

   async forgot(req,res){
     const {email} = req.body;
      try{
       const user = await MyModel.findOne({email})
  
       if(!user)
          return res.status(400).send({error:'User not found'})

        const token = await crypto.randomBytes(20).toString('hex')
        const now = new Date()
          now.setHours(now.getHours() + 1)
        await MyModel.findByIdAndUpdate(user.id,{
          '$set':{
            passwordResetToken:token,
            passwordResetExpire:now
          }
        });
        console.log(token)
        mailer.sendMail({
          from:'sr.lobak@gmail.com',
          to:email,
          tamplate:'email',
          html:` <h1>Voce esqueceu sua senha, Nao tem problema!</h1>
                 <p>Utilize esse token:${token}</p>`,
          
        }).then(()=>{
         res.status(200).send({acepted:'token sended'})
        }).catch((err)=>{
         res.status(400).send({err:'erro send email'+err})
        })
      }catch(err){
       res.status(400).send({err:`Erro on forgot password, try again ${err}`})
       console.log(err)
      }
   },
   async resetPassword(req,res){
    const {email,token,password} = req.body;
    const user = await MyModel.findOne({email}).select('+passwordResetToken passwordResetExpires')

    try{
     if(!user)
        return res.status(400).send({error:'User not found'})
     if(token !==user.passwordResetToken)
        return res.status(400).send({error:'Token invalid'})
     const now = new Date()
     
     if (now > user.passwordResetExpire)
       return res.status(400).send({error:'Token expired'})
     user.password=password
     await user.save()
     res.send()

    }catch(err){
      res.status(400).send({error:'Cannot reset password'})
    }
   }

}