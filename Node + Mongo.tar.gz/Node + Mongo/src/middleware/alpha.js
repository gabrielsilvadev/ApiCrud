const jwt = require('jsonwebtoken');
const auth = require('../config/autha.json')

module.exports = (req,res,next)=>{
    const authheadrs = req.headers.authorization;
    
    if(!authheadrs)
    return res.status(401).send({err:'error'})

    const parts = authheadrs.split(' ')

    if (!parts.length===2)
     return res.status(401).send({err:'Token invalido'})
    const [scheme,token] = parts


    if(!/^Bearer$/i.test(scheme))
    return res.status(401).send({error:'Token mal formado'});

   jwt.verify(token,auth.secret,(err,decoded)=>{
     if (err) return res.status(401).send({error:'Token invalido'})
     req.userId = decoded.id
     return next()
   })

}