const path = require('path')

const nodemailer = require('nodemailer')

const hbs = require('nodemailer-express-handlebars')

const {host,port,user,pass} = require('../config/mail.json')

const transport = nodemailer.createTransport({
     host,
     port,
    auth: {
      user,
      pass
    }
  });

const email =transport.use('compile',hbs({
    viewEngine:'handlebars',
    viewPath:path.resolve('./resources/mail/auth'),
    extName:'.html'
}))
module.exports=transport