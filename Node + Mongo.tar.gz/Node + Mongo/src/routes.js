const express = require('express');
const controllerUser = require('./controller/controllerUser')
const controllerProject= require('./controller/controllerProjetos')
const authMiddle = require('./middleware/alpha');
const router = express.Router();



// Routes to Users

router.post('/create',controllerUser.create);
router.post('/auth',controllerUser.auth);
router.post('/forgot_password',controllerUser.forgot)
router.post('/reset',controllerUser.resetPassword)
router.use(authMiddle)
router.get('/validation',controllerUser.validationUser)


// Routes to Project
router.get('/projectAll',controllerProject.projectAll)
router.get('/project/lists/:projectId',controllerProject.listProject)
router.post('/createProject',controllerProject.create)
router.put('/project/:projectId',controllerProject.edition)
router.delete('/delete',controllerProject.delete)
module.exports=router