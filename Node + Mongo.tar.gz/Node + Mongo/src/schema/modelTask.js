const mongoose = require('./conection')

const TaskSchema =  mongoose.Schema({
    title:{
        type: String,
        required:true
    },
    project:{
     type:mongoose.Schema.Types.ObjectId,
     ref:'Project',
     require:true
    },
    assinedTo:{
     type:mongoose.Schema.Types.ObjectId,
     ref:'User',
     require:true
    },
    completed:{
     type:Boolean,
     require:true,
     default:false
    },
    createAt:{
        type:Date,
        default:Date.now

    }
})
  
 const  Task = mongoose.model('Task',TaskSchema)

module.exports = Task;
