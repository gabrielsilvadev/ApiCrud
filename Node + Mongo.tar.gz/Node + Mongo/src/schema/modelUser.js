const mongoose = require('./conection')

const UserSchema =  mongoose.Schema({
    name:{
        type: String,
        required:true
    },
    sobrenome:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true,
        unique:true,
        lowercase:true
    },
    idade:{
        type:Number,
        required:true
    },
    password:{
        type:String,
        required:true,
        select:false 
    },
    passwordResetToken:{
     type:String,
     select:false
    },
    passwordResetExpires:{
     type:Date,
     select:false
    },
    createAt:{
        type:Date,
        default:Date.now

    }
})
  
 const  myModel = mongoose.model('User',UserSchema)

module.exports = myModel;
